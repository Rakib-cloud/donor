Free Download Image Used Links
-https://pixabay.com/photos/medical-appointment-doctor-563427/
-https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pngfuel.com%2Fsearch%3Fq%3Dpulmonary%2BCirculation&psig=AOvVaw18G6Xo4FISmeMQTmcj79Hr&ust=1600995416529000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMC_3vHKgOwCFQAAAAAdAAAAABAJ
-https://www.google.com/url?sa=i&url=https%3A%2F%2Fpt.dreamstime.com%2Ffoto-de-stock-estetosc%25C3%25B3pio-dos-instrumentos-m%25C3%25A9dicos-%25C3%25A0-disposi%25C3%25A7%25C3%25A3o-do-beb%25C3%25AA-rec%25C3%25A9m-nascido-image57898735&psig=AOvVaw0xFKAJPm8_t92v0-0uBrSB&ust=1600996123043000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCOil-cDNgOwCFQAAAAAdAAAAABAL
-https://cdn2.vectorstock.com/i/thumb-large/76/86/human-anatomy-orthopedic-vector-16867686.jpg
-https://www.kindpng.com/picc/m/127-1272273_doctors-logo-black-and-white-vector-png-download.png
-https://www.freepnglogos.com/uploads/doctor-png/doctor-bulk-billing-doctors-chapel-hill-health-care-medical-3.png
-https://toppng.com/uploads/preview/doctors-11530977532oiutm9guyq.png
-https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQMSOI74RIlZiBnp7hQWrkUY-fZGgYNTVJopg&usqp=CAU
