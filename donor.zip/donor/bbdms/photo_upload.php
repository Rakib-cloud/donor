<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
	{
header('location:index.php');
}
else{
	if(ISSET($_POST['upload'])){
		$file_name = $_FILES['image']['name'];
		$file_temp = $_FILES['image']['tmp_name'];
		$allowed_ext = array("jpeg", "jpg", "gif", "png");
		$exp = explode(".", $file_name);
		$ext = end($exp);
		$path = "upload/".$file_name;
		if(in_array($ext, $allowed_ext)){
			if(move_uploaded_file($file_temp, $path)){
				try{
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = "INSERT INTO `tblblooddonars`(image_name)  VALUES ('$file_name')";
					$dbh->exec($sql);
				}catch(PDOException $e){
					echo $e->getMessage();
				}

				$dbh = null;
				header('location: index.php');
			}
		}else{
			echo "<center><h3 class='text-danger'>Only image format can be upload</h3></center>";
		}
	}
}
?>





<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	</head>
<body ng-app="myModule" ng-controller="myController">

	<div class="col-md-3"></div>
	<div class="col-md-6 well">
		<h3 class="text-primary">PHP - Simple Image Upload Using PDO</h3>
		<hr style="border-top:1px dotted #ccc;">
		<div class="col-md-3">
			<form method="POST" enctype="multipart/form-data" action="upload.php">
				<div class="form-group">
					<label>Upload here</label>
					<input name="image" type="file" class="form-control" required="required"/>
				</div>
				<center><button class="btn btn-primary" name="upload">Upload</button></center>
			</form>
		</div>


	</div>
</body>
</html>
