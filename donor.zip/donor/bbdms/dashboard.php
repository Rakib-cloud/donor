<?php
session_start();
include('includes/config.php');
if(isset($_POST['login']))
{
$email=$_POST['username'];
$password=$_POST['password'];
$sql ="SELECT * FROM tblblooddonars WHERE EmailId=:email and p=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['email']=$email;
$_SESSION['password'] = $password;
echo "<script type='text/javascript'> document.location = 'user_pass_change.php'; </script>";
} else{

  echo "<script>alert('Invalid Details');</script>";

}

}

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BloodBank & Donor | Become A Donar</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="admin/css/modern-business.css" rel="stylesheet">
		<link rel="stylesheet" href="admin/css/font-awesome.min.css">
		<!-- Sandstone Bootstrap CSS -->
		<link rel="stylesheet" href="admin/css/bootstrap.min.css">
		<!-- Bootstrap Datatables -->
		<link rel="stylesheet" href="admin/css/dataTables.bootstrap.min.css">
		<!-- Bootstrap social button library -->
		<link rel="stylesheet" href="admin/css/bootstrap-social.css">
		<!-- Bootstrap select -->
		<link rel="stylesheet" href="admin/css/bootstrap-select.css">
		<!-- Bootstrap file input -->
		<link rel="stylesheet" href="admin/css/fileinput.min.css">
		<!-- Awesome Bootstrap checkbox -->
		<link rel="stylesheet" href="admin/css/awesome-bootstrap-checkbox.css">
		<!-- Admin Stye -->
		<link rel="stylesheet" href="admin/css/style.css">admin/

    <style>
    .navbar-toggler {
        z-index: 1;
    }

    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>


</head>

<body>


  <div class="brand clearfix">
  	<a href="dashboard.php" style="font-size: 20px; padding-top:1%; color:#fff">BloodBank Management System </a>
  		<span class="menu-btn"><i class="fa fa-bars"></i></span>
  		<ul class="ts-profile-nav">

  			<li class="ts-account">
  				<a href="photo_upload.php"><img src="images/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
  				<ul>
  					<li>
              

            </li>
  						<li><a href="user_update.php">Update Information</a></li>
  					<li><a href="user_logout.php">Logout</a></li>
  				</ul>
  			</li>
  		</ul>
  	</div>

    <!-- Page Content -->
    <div class="container">


        <!-- Page Heading/Breadcrumbs -->


        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Search  Donor</li>
        </ol>
        <!-- <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php }
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>-->
        <!-- Content Row -->


        <div class="row">
                   <?php


$status=1;
$email=$_SESSION['email'];
$password=$_SESSION['password'];

$sql = "SELECT * from tblblooddonars where (status=:status and EmailId=:email) and  (p=:password)";
$query = $dbh -> prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>

            <div class="col-lg-4 col-sm-6 portfolio-item">
                <div class="card h-100">
                    <a href="#"><img class="card-img-top img-fluid" src="upload/<?php echo htmlentities($result->FullName);?>" alt="" ></a>
                    <div class="card-block">
                        <h4 class="card-title"><a href="#"><?php echo htmlentities($result->FullName);?></a></h4>
                        <img class="card-img-top img-fluid" src="upload/<?php echo htmlentities($result->image_name);?>" alt="" >
                        <p class="card-text"><b>Mobile No :</b> <?php echo htmlentities($result->MobileNumber);?> </p>
												<p class="card-text"><b>Email Id :</b> <?php echo htmlentities($result->EmailId);?></p>

<p class="card-text"><b>  Gender :</b> <?php echo htmlentities($result->Gender);?></p>
<p class="card-text"><b> Age:</b> <?php echo htmlentities($result->Age);?></p>
<p class="card-text"><b>Blood Group :</b> <?php echo htmlentities($result->BloodGroup);?></p>
<p class="card-text"><b>Last Donation :</b> <?php echo htmlentities($result->ld);?></p>
<p class="card-text"><b>Health Condition :</b> <?php echo htmlentities($result->h);?></p>
<p class="card-text"><b>Address :</b>
<?php if($result->Address=="")
{
echo htmlentities('NA');
} else {
echo htmlentities($result->Address);
}
?></p>
     <p class="card-text"><b>Body Remarks :</b> <?php echo htmlentities($result->Message);?></p>

                    </div>
                </div>
            </div>

            <?php }}
else
{
echo htmlentities("No Record Found");

}


             ?>





        </div>



</div>
  <?php include('includes/footer.php');?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
