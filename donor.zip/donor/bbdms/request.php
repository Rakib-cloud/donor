<?php

$servername='localhost';
$username='root';
$password='';
$dbname = "bbdms";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}

if(isset($_POST['request']))
{ 

$fullname=$_POST['fullname'];
$Address=$_POST['Address'];
$bloodgroup=$_POST['bloodgroup'];
$phno=$_POST['phno'];
$unit=$_POST['unit'];
$time=$_POST['bloodtime'];
 $sql = "INSERT INTO `requestblood`(`id`, `user`, `Address`, `bloodgroup`, `phno`, `unit`, `time-for-flood`) VALUES ('','$fullname','$Address','$bloodgroup','$phno','$unit','$time')";
   if (mysqli_query($conn, $sql)) {
    echo "New record created successfully !";
   } else {
    echo "Error: " . $sql . "
" . mysqli_error($conn);
   }
   mysqli_close($conn);
}
?>
  
        <html>
     <head>
            <link rel="stylesheet" type="text/css" href="css/mordern-business.css">

  <title>Request Blood</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BloodBank & Donor</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }

    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    .carousel-item.active,
    .carousel-item-next,
    .carousel-item-prev {
        display: block;
    }
    </style>
   </head>
           <body>

            <?php include('includes/header.php');?>

   

<center>                 <h2 style="background-color: black ; color: white">Send Blood Request</h2></center>  

                 
                    <hr>
                    <form action="" style="margin-right: 500px; margin-left: 500px; " method="post">                   
                    <label>Enter Your Full Name<span>*</span></label><br>
                    <input type="text" name="fullname" id="fullname" >
                    <div class="required"></div>
                    <br>
                    
                    <!--Last Name-->
                    <label>Your Address<span>*</span></label><br>
                    <input type="text" name="Address" id="Address">
                    <div class="required"></div>
                    <br>
                    <!--Nickname-->
                    <label>Bloodgroup You Want</label><br>
                    <input type="text" name="bloodgroup" id="bloodgroup">
                    <div class="required"></div>
                    <br>
                    <label>Your Contact Number<span>*</span></label><br>
                    <input type="Number" name="phno" id="phno"><br>

                    <label>Unit<span>*</span></label><br>
                    <input type="Number" name="unit" id="unit">
                    <div class="required"></div>

                    <br>
                    <label>Time Of blood need<span>*</span></label><br>
                    <input type="text" name="bloodtime" id="bloodtime">
                    <div class="required"></div>
<br>
                    <input style="background-color: blue; color: white" type="submit" value="Request" name="request">
                </form>
               
            </div>
        </div>

     <?php include('includes/footer.php');?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    </div>
    <script src="js/jqBootstrapValidation.js"></script>

</body>
</html>

                    
      

     


  

    