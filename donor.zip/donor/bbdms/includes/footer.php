

  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Blood Donor  <a href="http://www.uiu.ac.bd/">SAD_PROJECT</a></p>
        </div>
        <!-- /.container -->
    </footer>
