<?php
	require_once 'includes/config.php';

	if(ISSET($_POST['upload'])){
		$file_name = $_FILES['image']['name'];
		$file_temp = $_FILES['image']['tmp_name'];
		$allowed_ext = array("jpeg", "jpg", "gif", "png");
		$exp = explode(".", $file_name);
		$ext = end($exp);
		$path = "upload/".$file_name;
		if(in_array($ext, $allowed_ext)){
			if(move_uploaded_file($file_temp, $path)){
				try{
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = "INSERT INTO `image`(image_name, location)  VALUES ('$file_name', '$path')";
					$dbh->exec($sql);
				}catch(PDOException $e){
					echo $e->getMessage();
				}

				$dbh = null;
				header('location: index.php');
			}
		}else{
			echo "<center><h3 class='text-danger'>Only image format can be upload</h3></center>";
		}
	}
?>
<!DOCTYPE html>
<html>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="image" id="image">
    <input type="submit" value="Upload Image" name="upload">
</form>

</body>
</html>
